      
//
// WebGPU Square
//
//     
async function Main()
{
      const canvas = document.querySelector("canvas");

      // WebGPU device initialization
      if (!navigator.gpu) {
        throw new Error("WebGPU not supported on this browser.");
      }

      const adapter = await navigator.gpu.requestAdapter();
      if (!adapter) {
        throw new Error("No appropriate GPUAdapter found.");
      }
      console.log(adapter)

      const device = await adapter.requestDevice();
      console.log

      // Canvas configuration
      const context = canvas.getContext("webgpu");
      const canvasFormat = navigator.gpu.getPreferredCanvasFormat();
      context.configure({
          device: device,
          format: canvasFormat,
      });

            // Create a buffer with the vertices for a single cell.
            const squareVerts = new Float32Array([
              //   X,    Y
                -0.1, -0.1, // Triangle 1
                 0.1, -0.1,
                 0.1,  0.1,
        
                -0.1, -0.1, // Triangle 2
                 0.1,  0.1,
                -0.1,  0.1,
              ]);

      const rectVerts = createRectVerts(0.7, 0.7, 0.8, .1);
      const circleVerts = createCircleVerts(-0.75, -0.75, 0.2, 12);
      const triangleVerts = createCircleVerts(0.4, 0.3, 0.2, 3);
      const pentagonVerts = createCircleVerts(-0.6, 0.2, 0.3, 5);
      const diamondVerts = createCircleVerts(0.4, -0.6, 0.2, 4);

      const {sqrVerts : squareVerts2, nSqrVerts : nSquareVerts2} = createRectVerts(.8, .8, .3, .1);
      const {circleVerts2, numVertices } = createCircleVerts(0.0, 0.0, .5, 36);

      const allVerts = new Float32Array([...rectVerts, ...squareVerts, ...circleVerts, ...pentagonVerts, ...diamondVerts, ...triangleVerts]);

function createRectVerts(cx, cy, width, height) {
  return [
      cx - width, cy - height,  // Triangle 1
      cx + width, cy - height,
      cx + width, cy + height,

      cx - width, cy - height,  // Triangle 2
      cx + width, cy + height,
      cx - width, cy + height,
  ];
}

function createCircleVerts(cx, cy, radius, nSubdivisions) {
  const verts = [];
  const angle = (Math.PI * 2) / nSubdivisions;

  for (let i = 0; i < nSubdivisions; i++) {
      const edgeOne = i * angle;
      const edgeTwo = (i + 1) * angle;

      verts.push(cx, cy);
      verts.push(cx + radius * Math.cos(edgeOne), cy + radius * Math.sin(edgeOne));
      verts.push(cx + radius * Math.cos(edgeTwo), cy + radius * Math.sin(edgeTwo));
  }
  return verts;
}

      const vertexBuffer = device.createBuffer({
        label: "Square vertices",
        size: allVerts.byteLength,
        usage: GPUBufferUsage.VERTEX | GPUBufferUsage.COPY_DST,
      });
      device.queue.writeBuffer(vertexBuffer, 0, allVerts);

      const vertexBufferLayout = {
        arrayStride: 8,
        attributes: [{
          format: "float32x2",
          offset: 0,
          shaderLocation: 0, // Position. Matches @location(0) in the @vertex shader.
        }],
      };

      // Create the shader that will render the cells.
      const ShaderModule = device.createShaderModule({
        label: "Cell shader",
        code: `
          @vertex
          fn vertexMain(@location(0) pos: vec2f) -> @builtin(position) vec4f {
            return vec4f(pos, 0, 1);
          }

          @fragment
          fn fragmentMain() -> @location(0) vec4f {
            return vec4f(1, 1, 0, 1);
          }
        `
      });

      // Create a pipeline that renders the square
      const Pipeline = device.createRenderPipeline({
        label: "Cell pipeline",
        layout: "auto",
        vertex: {
          module: ShaderModule,
          entryPoint: "vertexMain",
          buffers: [vertexBufferLayout]
        },
        fragment: {
          module: ShaderModule,
          entryPoint: "fragmentMain",
          targets: [{
            format: canvasFormat
          }]
        }
      });

      // Clear the canvas with a render pass
      const encoder = device.createCommandEncoder();

      const pass = encoder.beginRenderPass({
        colorAttachments: [{
          view: context.getCurrentTexture().createView(),
          loadOp: "clear",
          clearValue: { r: 0, g: 0.3, b: 0.3, a: 0.5 },
          storeOp: "store",
        }]
      });

      // Draw the square.
      pass.setPipeline(Pipeline);
      
      pass.setVertexBuffer(0, vertexBuffer);
      pass.draw(allVerts.length / 2);
      pass.end();

      device.queue.submit([encoder.finish()]);
}

Main();